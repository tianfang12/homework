package utils;

import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class Deal_text {
	public static Set<Map.Entry<String,Integer>> deal_content(String content){
			//content的空白和换行处理
	       StringTokenizer words = new StringTokenizer(content);
		 	
		   	//处理空白数据，以及转化首字母小写
	        Map<String,Integer> map=new TreeMap<>();
	        while(words.hasMoreTokens()){	
	        	String s=words.nextToken();
	        	//	以第二个参数处理数组，返回一个StringTolken数组
	        	StringTokenizer st = new StringTokenizer(s," .;:”“,[]{}?()!@#$%^&*~<>/|+=-—_\"");
	        	//获取字符
	        	while(st.hasMoreTokens()){	
	        		String ss=st.nextToken();
		 		//去掉首尾部的'
	        	if(ss.startsWith("'"))
		 			ss=ss.substring(1);
		 		if(ss.endsWith("'"))
		 			ss=ss.substring(0,ss.length()-1);
	        	    //判断数字
		 			if(! Num.isNumeric(ss))
	        		 	//如果处理完，不是只是剩下'，将其转换小写并保存
		 				if(!ss.equals("'")){
	        		 		String key=ss.toLowerCase();
	 			              if(!map.containsKey(key)) { 
	 			            	  map.put(key,1);
	 			              }
	 			                else{
	 			                    int value=map.get(key);
	 			                    value++;
	 			                    
	 			                    map.put(key,value);
	 			                }

	        		 	}
	        	}
	        }
	        //建立映射
	        Set<Map.Entry<String,Integer>> entrySet=map.entrySet();
	        return entrySet;
	}
}
