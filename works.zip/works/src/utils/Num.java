package utils;

public class Num {
	//判断字符串是否为数值
	  public static boolean isNumeric(String str ){
		   for (int i = str.length();--i>=0;){  
		        if (!Character.isDigit(str.charAt(i))){
		           return false;
		       }
		   }
		    return true;
	   }
	  
}
